public interface RentalCostStrategy {
    double calculateCost(int days, double baseRate);
}

