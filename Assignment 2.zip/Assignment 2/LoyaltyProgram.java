public interface LoyaltyProgram {
    void addLoyaltyPoints(Customer customer, int points);
}

